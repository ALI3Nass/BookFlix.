<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
    <!DOCTYPE html>
    <html>

    <head>
        <title>Home</title>
        <link rel="stylesheet" href="css/head.css">
    </head>

    <body>
        <div class="container">
            <h1 class="lead typewriter">BookFlix</h1>
            <div class="header-bar">
                <ul class="slider-menu">
                    <li>
                        <button class="button transparen" type="submit">Search</button>
                    </li>
                    <li>
                        <form action="/search" method="GET">
                            <div class="search-form">
                                <input type="text" name="search" placeholder="Search products...">
                                <div class="underline"></div>
                            </div>
                        </form>

                    </li>
                    <li><a href="store.blade.php">Books &amp; Notes</a></li>
                    <li>
                        <button id="upload-btn" class="button transparen">Upload</button>
                        <input type="file" id="file-input" style="display:none;">
                    </li>
                </ul>
            </div>
        </div>
        <footer>
            <p>© 2023 Bookflix. All rights reserved.</p>
        </footer>
    </body>

    </html>

    <script>
        const uploadBtn = document.getElementById('upload-btn');
        const fileInput = document.getElementById('file-input');
        uploadBtn.addEventListener('click', () => {
            fileInput.click();
        });
    </script><?php /**PATH /home/alien/Documents/Web_Dev./BookFlix/resources/views/welcome.blade.php ENDPATH**/ ?>