<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="View Itemport" content="width=device-width, initial-scale=1.0" />
  <title>BookFlix</title>
  <link rel="stylesheet" href="/css/style.css" />
</head>

<body>

  <header>
    <h1 style="font-family: CustomFont1;">BookFlix</h1>
  </header>

  <div class="product-grid">
    <div class="product-card">
      <img src="https://via.placeholder.com/250x250" alt="Product" />
      <h4 class="product-name">"Quantum Computing An Applied Approach"</h4>
      <p>$99.99</p>
      <div class="button-container">
        <button class="button">View Item</button>
        <button class="button">Contact Seller</button>
      </div>
    </div>
    <div class="product-card">
      <img src="https://via.placeholder.com/250x250" alt="Product" />
      <h4 class="product-name">"Principles of Quantum Mechanics" by R. Shankar</h4>
      <p>$99.99</p>
      <div class="button-container">
        <button class="button">View Item</button>
        <button class="button">Contact Seller</button>
      </div>
    </div>
    <div class="product-card">
      <img src="https://via.placeholder.com/250x250" alt="Product" />
      <h4 class="product-name">"Quantum Mechanics: Concepts and Applications" by Nouredine Zettili</h4>
      <p>$99.99</p>
      <div class="button-container">
        <button class="button">View Item</button>
        <button class="button">Contact Seller</button>
      </div>
    </div>
    <div class="product-card">
      <img src="https://via.placeholder.com/250x250" alt="Product" />
      <h4 class="product-name">"Modern Quantum Mechanics" by J. J. Sakurai and Jim Napolitano</h4>
      <p>$99.99</p>
      <div class="button-container">
        <button class="button">View Item</button>
        <button class="button">Contact Seller</button>
      </div>
    </div>
    <div class="product-card">
      <img src="https://via.placeholder.com/250x250" alt="Product" />
      <h4 class="product-name">"Quantum Mechanics and Path Integrals" by Richard P. Feynman and Albert R. Hibbs</h4>
      <p>$99.99</p>
      <div class="button-container">
        <button class="button">View Item</button>
        <button class="button">Contact Seller</button>
      </div>
    </div>
    <div class="product-card">
      <img src="https://via.placeholder.com/250x250" alt="Product" />
      <h4 class="product-name">"Artificial Intelligence: A Modern Approach" by Stuart Russell and Peter Norvig</h4>
      <p>$9.99</p>
      <div class="button-container">
        <button class="button">View Item</button>
        <button class="button">Contact Seller</button>
      </div>
    </div>
    <div class="product-card">
      <img src="https://via.placeholder.com/250x250" alt="Product" />
      <h4 class="product-name">"Hands-On Machine Learning with Scikit-Learn, Keras, and TensorFlow" by Aurélien Géron
      </h4>
      <p>$9.99</p>
      <div class="button-container">
        <button class="button">View Item</button>
        <button class="button">Contact Seller</button>
      </div>
    </div>
    <div class="product-card">
      <img src="https://via.placeholder.com/250x250" alt="Product" />
      <h4 class="product-name">"Deep Learning" by Ian Goodfellow, Yoshua Bengio, and Aaron Courville</h4>
      <p>$9.99</p>
      <div class="button-container">
        <button class="button">View Item</button>
        <button class="button">Contact Seller</button>
      </div>
    </div>
    <div class="product-card">
      <img src="https://via.placeholder.com/250x250" alt="Product" />
      <h4 class="product-name">"Deep Learning" by Ian Goodfellow, Yoshua Bengio, and Aaron Courville</h4>
      <p>$9.99</p>
      <div class="button-container">
        <button class="button">View Item</button>
        <button class="button">Contact Seller</button>
      </div>
    </div>
    <div class="product-card">
      <img src="https://via.placeholder.com/250x250" alt="Product" />
      <h4 class="product-name">"Deep Learning" by Ian Goodfellow, Yoshua Bengio, and Aaron Courville</h4>
      <p>$9.99</p>
      <div class="button-container">
        <button class="button">View Item</button>
        <button class="button">Contact Seller</button>
      </div>
    </div>
    <div class="product-card">
      <img src="https://via.placeholder.com/250x250" alt="Product" />
      <h4 class="product-name">"Deep Learning" by Ian Goodfellow, Yoshua Bengio, and Aaron Courville</h4>
      <p>$9.99</p>
      <div class="button-container">
        <button class="button">View Item</button>
        <button class="button">Contact Seller</button>
      </div>
    </div>
    <div class="product-card">
      <img src="https://via.placeholder.com/250x250" alt="Product" />
      <h4 class="product-name">"Deep Learning" by Ian Goodfellow, Yoshua Bengio, and Aaron Courville</h4>
      <p>$9.99</p>
      <div class="button-container">
        <button class="button">View Item</button>
        <button class="button">Contact Seller</button>
      </div>
    </div>
    <div class="product-card">
      <img src="https://via.placeholder.com/250x250" alt="Product" />
      <h4 class="product-name">"Deep Learning" by Ian Goodfellow, Yoshua Bengio, and Aaron Courville</h4>
      <p>$9.99</p>
      <div class="button-container">
        <button class="button">View Item</button>
        <button class="button">Contact Seller</button>
      </div>
    </div>
    <div class="product-card">
      <img src="https://via.placeholder.com/250x250" alt="Product" />
      <h4 class="product-name">"Deep Learning" by Ian Goodfellow, Yoshua Bengio, and Aaron Courville</h4>
      <p>$9.99</p>
      <div class="button-container">
        <button class="button">View Item</button>
        <button class="button">Contact Seller</button>
      </div>
    </div>
  </div>

  <footer>
    <p>© 2023 BookFlix. All rights reserved.</p>
  </footer>

</body>

</html>

